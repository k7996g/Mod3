package com.cg.capstore.repo;

import com.cg.capstore.beans.Product;

public interface DiscountRepo {
	Product applyDiscount(int prodId);
	
}
