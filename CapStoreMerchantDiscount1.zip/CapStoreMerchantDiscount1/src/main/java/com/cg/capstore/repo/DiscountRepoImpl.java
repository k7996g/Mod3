package com.cg.capstore.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.capstore.beans.Coupon;
import com.cg.capstore.beans.Product;

@Repository()
public class DiscountRepoImpl implements DiscountRepo {
	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	List<Coupon> a = new ArrayList<>();

	@Override
	public Product applyDiscount(int prodId) {
		Product product = entityManager.find(Product.class, prodId);
		
		 
			double discount = product.getProdDiscount();
           
			
			if (discount == 0)
				System.err.println("There is no discount on this product");
			else {
				product.setPrice(product.getPrice() - discount);
			}

			// entityManager.persist(product);
			return product;

		

	}

	

}
